package app.beestore;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * Bee Store : le site du store dans une WebView, plus un téléchargeur et un lanceur d'installation.
 * Le site appelle BeeNative.download(url, nom, sha256) ; l'application télécharge l'APK avec une barre de
 * progression, vérifie l'empreinte si elle est fournie, puis ouvre l'installeur d'Android.
 */
public class MainActivity extends Activity {

    private static final String SITE = BuildConfig.SITE_URL;

    private WebView web;
    private LinearLayout bar;
    private ProgressBar progress;
    private TextView status;

    private volatile boolean cancelled = false;
    private Thread worker;
    private File pendingApk; // APK téléchargé, en attente de l'autorisation « sources inconnues »

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Barre de téléchargement, en bas de l'écran.
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#17142b"));
        int pad = dp(14);
        bar.setPadding(pad, pad, pad, pad);
        bar.setVisibility(View.GONE);
        bar.setClickable(true);

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        bar.addView(status);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        pl.topMargin = dp(8);
        bar.addView(progress, pl);

        Button cancel = new Button(this);
        cancel.setText("Annuler");
        cancel.setOnClickListener(v -> cancelDownload());
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cl.gravity = Gravity.END;
        cl.topMargin = dp(6);
        bar.addView(cancel, cl);

        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(bar, bl);
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " BeeStoreApp/1");
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "BeeNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.equalsIgnoreCase(Uri.parse(SITE).getHost())) return false; // pages du store : dans l'application
                String path = u.getPath() == null ? "" : u.getPath();
                if ("https".equals(u.getScheme()) && path.contains("/download/")) {
                    startDownload(u.toString(), "app.apk", null); // lien de téléchargement ouvert comme une page
                    return true;
                }
                openExternal(u); // Telegram, autres sites : hors de l'application
                return true;
            }
        });
        web.setDownloadListener((url, ua, disposition, mime, length) ->
                startDownload(url, URLUtil.guessFileName(url, disposition, mime), null));

        if (b == null) web.loadUrl(SITE); else web.restoreState(b);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Retour de l'écran « autoriser l'installation » : on relance l'installation en attente.
        if (pendingApk != null && canInstall()) {
            File f = pendingApk;
            pendingApk = null;
            install(f);
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    /* ---------- pont JavaScript : window.BeeNative ---------- */
    private class Bridge {
        @JavascriptInterface
        public boolean isNative() { return true; }

        @JavascriptInterface
        public void download(final String url, final String name, final String sha256) {
            runOnUiThread(() -> startDownload(url, name, sha256));
        }

        @JavascriptInterface
        public void cancel() { runOnUiThread(MainActivity.this::cancelDownload); }
    }

    /* ---------- téléchargement ---------- */
    private void startDownload(final String url, String name, final String sha256) {
        if (url == null || !url.startsWith("https://")) { toast("Adresse de téléchargement refusée."); return; }
        if (worker != null && worker.isAlive()) { toast("Un téléchargement est déjà en cours."); return; }

        File dir = new File(getExternalFilesDir(null), "apk");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) //noinspection ResultOfMethodCallIgnored
            f.delete();

        String safe = (name == null || name.trim().isEmpty() ? "app.apk" : name).replaceAll("[^A-Za-z0-9._-]+", "-");
        if (!safe.toLowerCase(Locale.ROOT).endsWith(".apk")) safe += ".apk";
        final File out = new File(dir, safe);
        final String label = safe;

        cancelled = false;
        showBar("Connexion…", 0);
        worker = new Thread(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(20000);
                c.setReadTimeout(60000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "BeeStoreApp/1");
                int code = c.getResponseCode();
                if (code / 100 != 2) throw new IOException("réponse " + code);
                long total = c.getContentLengthLong();
                long done = 0, lastUi = 0;
                try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (cancelled) throw new InterruptedIOException();
                        fo.write(buf, 0, n);
                        done += n;
                        long now = System.currentTimeMillis();
                        if (now - lastUi > 250) {
                            lastUi = now;
                            final long d = done, t = total;
                            runOnUiThread(() -> showBar(label, t > 0 ? (int) (d * 1000 / t) : -1, d, t));
                        }
                    }
                }
                if (total > 0 && done != total) throw new IOException("fichier incomplet");
                if (sha256 != null && sha256.length() == 64 && !sha256.equalsIgnoreCase(sha256(out))) {
                    //noinspection ResultOfMethodCallIgnored
                    out.delete();
                    runOnUiThread(() -> { hideBar(); toast("Fichier corrompu : l'empreinte ne correspond pas. Installation annulée."); });
                    return;
                }
                runOnUiThread(() -> { hideBar(); install(out); });
            } catch (InterruptedIOException e) {
                //noinspection ResultOfMethodCallIgnored
                out.delete();
                runOnUiThread(() -> { hideBar(); toast("Téléchargement annulé."); });
            } catch (Exception e) {
                //noinspection ResultOfMethodCallIgnored
                out.delete();
                final String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                runOnUiThread(() -> { hideBar(); toast("Échec du téléchargement : " + msg); });
            } finally {
                if (c != null) c.disconnect();
            }
        }, "bee-download");
        worker.start();
    }

    private void cancelDownload() { cancelled = true; }

    private static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte x : md.digest()) sb.append(String.format(Locale.ROOT, "%02x", x));
        return sb.toString();
    }

    /* ---------- installation ---------- */
    private boolean canInstall() {
        return Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
    }

    private void install(File apk) {
        if (!canInstall()) {
            // Android demande d'autoriser Bee Store à installer des applications (une seule fois).
            pendingApk = apk;
            toast("Autorise Bee Store à installer des applications, puis reviens ici.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                toast("Ouvre les réglages Android pour autoriser l'installation d'applications.");
            }
            return;
        }
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Impossible de lancer l'installation : " + e.getMessage());
        }
    }

    /* ---------- interface ---------- */
    private void showBar(String label, int per) { showBar(label, per, 0, 0); }

    private void showBar(String label, int per, long done, long total) {
        bar.setVisibility(View.VISIBLE);
        if (per < 0) {
            progress.setIndeterminate(true);
            status.setText(label + " · " + mb(done));
        } else {
            progress.setIndeterminate(false);
            progress.setProgress(per);
            status.setText(total > 0 ? label + " · " + (per / 10) + " %  (" + mb(done) + " / " + mb(total) + ")" : label);
        }
    }

    private void hideBar() { bar.setVisibility(View.GONE); }

    private static String mb(long n) { return String.format(Locale.FRANCE, "%.1f Mo", n / 1048576.0); }

    private void toast(String t) { Toast.makeText(this, t, Toast.LENGTH_LONG).show(); }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void openExternal(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException e) {
            toast("Aucune application pour ouvrir ce lien.");
        }
    }
}
