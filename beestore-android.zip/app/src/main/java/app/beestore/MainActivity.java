package app.beestore;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.util.Locale;

/**
 * Bee Store : le site du store dans une WebView, plus un téléchargeur et un lanceur d'installation.
 * Le site appelle BeeNative.download(url, nom, sha256) ; l'application télécharge l'APK avec une barre de
 * progression, vérifie l'empreinte si elle est fournie, puis ouvre l'installeur d'Android.
 */
public class MainActivity extends Activity {

    private static final String SITE = BuildConfig.SITE_URL;

    private WebView web;
    private LinearLayout bar;
    private ProgressBar progress;
    private TextView status;
    private Ads ads;

    private File pendingApk; // APK téléchargé, en attente de l'autorisation « sources inconnues »
    private String[] pendingDl; // téléchargement en attente de la réponse à la demande de notifications

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        FrameLayout root = new FrameLayout(this);
        page.addView(root, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        FrameLayout adHolder = new FrameLayout(this);
        adHolder.setBackgroundColor(Color.parseColor("#0d0b20"));
        adHolder.setVisibility(View.GONE);
        page.addView(adHolder, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ads = new Ads(this, adHolder);
        new Thread(ads::start).start(); // le SDK de pub démarre hors du fil principal

        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Barre de téléchargement, en bas de l'écran.
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#17142b"));
        int pad = dp(14);
        bar.setPadding(pad, pad, pad, pad);
        bar.setVisibility(View.GONE);
        bar.setClickable(true);

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        bar.addView(status);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        pl.topMargin = dp(8);
        bar.addView(progress, pl);

        Button cancel = new Button(this);
        cancel.setText("Annuler");
        cancel.setOnClickListener(v -> cancelDownload());
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cl.gravity = Gravity.END;
        cl.topMargin = dp(6);
        bar.addView(cancel, cl);

        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(bar, bl);
        setContentView(page);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " BeeStoreApp/2");
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "BeeNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.equalsIgnoreCase(Uri.parse(SITE).getHost())) return false; // pages du store : dans l'application
                String path = u.getPath() == null ? "" : u.getPath();
                // Seuls nos propres serveurs (API Supabase, serveur MTProto) déclenchent un téléchargement d'APK.
                // Les liens externes (jeux pour émulateur, archive.org…) s'ouvrent dans le navigateur.
                String hl = host.toLowerCase(Locale.ROOT);
                boolean ownServer = hl.endsWith(".supabase.co") || hl.endsWith(".onrender.com");
                if ("https".equals(u.getScheme()) && ownServer && path.contains("/download/")) {
                    startDownload(u.toString(), "app.apk", null); // lien de téléchargement ouvert comme une page
                    return true;
                }
                openExternal(u); // Telegram, autres sites : hors de l'application
                return true;
            }
        });
        web.setDownloadListener((url, ua, disposition, mime, length) ->
                startDownload(url, URLUtil.guessFileName(url, disposition, mime), null));

        if (b == null) web.loadUrl(SITE); else web.restoreState(b);
        handleIntent(getIntent());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (ads != null) ads.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (ads != null) ads.destroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ads != null) ads.resume();
        // Retour de l'écran « autoriser l'installation » : on relance l'installation en attente.
        if (pendingApk != null && canInstall()) {
            File f = pendingApk;
            pendingApk = null;
            install(f);
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    /* ---------- pont JavaScript : window.BeeNative ---------- */
    private class Bridge {
        @JavascriptInterface
        public boolean isNative() { return true; }

        @JavascriptInterface
        public void download(final String url, final String name, final String sha256) {
            runOnUiThread(() -> startDownload(url, name, sha256));
        }

        @JavascriptInterface
        public void cancel() { runOnUiThread(MainActivity.this::cancelDownload); }

        @JavascriptInterface
        public int versionCode() {
            try {
                android.content.pm.PackageInfo p = getPackageManager().getPackageInfo(getPackageName(), 0);
                return (int) (Build.VERSION.SDK_INT >= 28 ? p.getLongVersionCode() : p.versionCode);
            } catch (Exception e) { return 0; }
        }

        @JavascriptInterface
        public String versionName() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Exception e) { return ""; }
        }

        /** Le site montre la bannière seulement sur l'accueil. */
        @JavascriptInterface
        public void banner(final boolean show) { runOnUiThread(() -> ads.showBanner(show)); }

        /** Vrai si une vidéo récompensée est prête à être montrée. */
        @JavascriptInterface
        public boolean rewardedReady() { return ads.rewardedReady(); }

        /** Montre la vidéo, puis appelle window.__adResult("rewarded" | "closed" | "error"). */
        @JavascriptInterface
        public void showRewarded() {
            runOnUiThread(() -> ads.showRewarded(r -> web.evaluateJavascript("window.__adResult && window.__adResult('" + r + "')", null)));
        }

        @JavascriptInterface
        public void share(final String title, final String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, title);
                i.putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(i, "Partager")); }
                catch (ActivityNotFoundException e) { toast("Partage impossible."); }
            });
        }
    }

    /* ---------- téléchargement (fait par DownloadService, en arrière-plan) ---------- */
    private void startDownload(final String url, String name, final String sha256) {
        if (url == null || !url.startsWith("https://")) { toast("Adresse de téléchargement refusée."); return; }
        if (DownloadService.active) { toast("Un téléchargement est déjà en cours."); return; }
        String[] dl = { url, name, sha256 };
        SharedPreferences prefs = getSharedPreferences("bee", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !prefs.getBoolean("askedNotif", false)) {
            // On demande une seule fois l'autorisation d'afficher la progression dans les notifications.
            prefs.edit().putBoolean("askedNotif", true).apply();
            pendingDl = dl;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            return;
        }
        beginDownload(dl);
    }

    private void beginDownload(String[] dl) {
        showBar("Connexion…", 0);
        DownloadService.start(this, dl[0], dl[1], dl[2]);
        toast("Le téléchargement continue même si tu quittes l'application.");
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 7 && pendingDl != null) { String[] dl = pendingDl; pendingDl = null; beginDownload(dl); }
    }

    private void cancelDownload() { DownloadService.cancelled = true; }

    private final DownloadService.Listener dlListener = new DownloadService.Listener() {
        @Override public void onProgress(String label, long done, long total) {
            runOnUiThread(() -> showBar(label, total > 0 ? (int) (done * 1000 / total) : -1, done, total));
        }
        @Override public void onDone(File apk) { runOnUiThread(() -> { hideBar(); install(apk); }); }
        @Override public void onFail(String msg) { runOnUiThread(() -> { hideBar(); toast(msg); }); }
    };

    @Override
    protected void onStart() {
        super.onStart();
        DownloadService.listener = dlListener;
        // Retour dans l'application pendant un téléchargement : on réaffiche la barre.
        if (DownloadService.active) showBar(DownloadService.curLabel, DownloadService.curTotal > 0 ? (int) (DownloadService.curDone * 1000 / DownloadService.curTotal) : -1, DownloadService.curDone, DownloadService.curTotal);
        else hideBar();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (DownloadService.listener == dlListener) DownloadService.listener = null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** Touche sur la notification « Téléchargement terminé » : on lance l'installation. */
    private void handleIntent(Intent intent) {
        if (intent == null) return;
        String path = intent.getStringExtra(DownloadService.EXTRA_INSTALL);
        if (path == null) return;
        intent.removeExtra(DownloadService.EXTRA_INSTALL);
        File f = new File(path);
        File dir = new File(getExternalFilesDir(null), "apk");
        try {
            if (f.isFile() && f.getCanonicalPath().startsWith(dir.getCanonicalPath() + File.separator)) install(f);
            else toast("Le fichier téléchargé n'existe plus. Recommence le téléchargement.");
        } catch (Exception e) {
            toast("Le fichier téléchargé n'existe plus. Recommence le téléchargement.");
        }
    }

    /* ---------- installation ---------- */
    private boolean canInstall() {
        return Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
    }

    private void install(File apk) {
        if (!canInstall()) {
            // Android demande d'autoriser Bee Store à installer des applications (une seule fois).
            pendingApk = apk;
            toast("Autorise Bee Store à installer des applications, puis reviens ici.");
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                toast("Ouvre les réglages Android pour autoriser l'installation d'applications.");
            }
            return;
        }
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Impossible de lancer l'installation : " + e.getMessage());
        }
    }

    /* ---------- interface ---------- */
    private void showBar(String label, int per) { showBar(label, per, 0, 0); }

    private void showBar(String label, int per, long done, long total) {
        bar.setVisibility(View.VISIBLE);
        if (per < 0) {
            progress.setIndeterminate(true);
            status.setText(label + " · " + mb(done));
        } else {
            progress.setIndeterminate(false);
            progress.setProgress(per);
            status.setText(total > 0 ? label + " · " + (per / 10) + " %  (" + mb(done) + " / " + mb(total) + ")" : label);
        }
    }

    private void hideBar() { bar.setVisibility(View.GONE); }

    private static String mb(long n) { return String.format(Locale.FRANCE, "%.1f Mo", n / 1048576.0); }

    private void toast(String t) { Toast.makeText(this, t, Toast.LENGTH_LONG).show(); }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void openExternal(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (ActivityNotFoundException e) {
            toast("Aucune application pour ouvrir ce lien.");
        }
    }
}
