package app.beestore;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * Télécharge l'APK en arrière-plan (service au premier plan, avec notification de progression).
 * L'écran de l'application s'abonne à l'avancement tant qu'il est visible ; sinon, une notification
 * « Touchez pour installer » est affichée à la fin.
 */
public class DownloadService extends Service {

    public interface Listener {
        void onProgress(String label, long done, long total);
        void onDone(File apk);
        void onFail(String message);
    }

    static final String ACTION_START = "app.beestore.START";
    static final String ACTION_CANCEL = "app.beestore.CANCEL";
    static final String EXTRA_INSTALL = "app.beestore.INSTALL";
    private static final String CH_PROGRESS = "progress";
    private static final String CH_DONE = "done";
    private static final int ID_PROGRESS = 1;
    private static final int ID_DONE = 2;

    static volatile Listener listener;
    static volatile boolean active;
    static volatile boolean cancelled;
    static volatile String curLabel = "";
    static volatile long curDone, curTotal;

    private Thread worker;
    private PowerManager.WakeLock wakeLock;

    static void start(Context c, String url, String name, String sha) {
        Intent i = new Intent(c, DownloadService.class).setAction(ACTION_START)
                .putExtra("url", url).putExtra("name", name).putExtra("sha", sha);
        ContextCompat.startForegroundService(c, i);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_CANCEL.equals(action)) {
            cancelled = true;
            if (!active) stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action)) { stopSelf(); return START_NOT_STICKY; }

        makeChannels();
        // startForeground doit être appelé tout de suite, sinon Android arrête le service.
        Notification first = progressNotification("Bee Store", "Connexion…", 0, true);
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID_PROGRESS, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(ID_PROGRESS, first);

        if (active) return START_NOT_STICKY; // un téléchargement est déjà en cours
        final String url = intent.getStringExtra("url");
        final String sha = intent.getStringExtra("sha");
        String name = intent.getStringExtra("name");
        if (url == null || !url.startsWith("https://")) { finishWith(null, "Adresse de téléchargement refusée."); return START_NOT_STICKY; }

        File dir = new File(getExternalFilesDir(null), "apk");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) //noinspection ResultOfMethodCallIgnored
            f.delete();
        String safe = (name == null || name.trim().isEmpty() ? "app.apk" : name).replaceAll("[^A-Za-z0-9._-]+", "-");
        if (!safe.toLowerCase(Locale.ROOT).endsWith(".apk")) safe += ".apk";
        final File out = new File(dir, safe);
        final String label = safe;

        active = true;
        cancelled = false;
        curLabel = label; curDone = 0; curTotal = 0;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "beestore:download");
            wakeLock.acquire(3 * 60 * 60 * 1000L);
        }
        worker = new Thread(() -> run(url, sha, out, label), "bee-download");
        worker.start();
        return START_NOT_STICKY;
    }

    private void run(String url, String sha, File out, String label) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(30000);
            c.setReadTimeout(90000); // le serveur gratuit peut mettre du temps à se réveiller
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "BeeStoreApp/2");
            int code = c.getResponseCode();
            if (code / 100 != 2) throw new IOException("réponse " + code);
            long total = c.getContentLengthLong();
            curTotal = total;
            long done = 0, lastUi = 0;
            try (InputStream in = c.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (cancelled) throw new InterruptedIOException();
                    fo.write(buf, 0, n);
                    done += n;
                    long now = System.currentTimeMillis();
                    if (now - lastUi > 500) {
                        lastUi = now;
                        curDone = done;
                        publish(label, done, total);
                    }
                }
            }
            if (total > 0 && done != total) throw new IOException("fichier incomplet");
            if (sha != null && sha.length() == 64 && !sha.equalsIgnoreCase(sha256(out))) {
                //noinspection ResultOfMethodCallIgnored
                out.delete();
                finishWith(null, "Fichier corrompu : l'empreinte ne correspond pas. Installation annulée.");
                return;
            }
            finishWith(out, null);
        } catch (InterruptedIOException e) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            finishWith(null, "Téléchargement annulé.");
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            finishWith(null, "Échec du téléchargement : " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void publish(String label, long done, long total) {
        Listener l = listener;
        if (l != null) l.onProgress(label, done, total);
        int per = total > 0 ? (int) (done * 1000 / total) : -1;
        String text = total > 0 ? (per / 10) + " %  (" + mb(done) + " / " + mb(total) + ")" : mb(done);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(ID_PROGRESS, progressNotification(label, text, per, false));
    }

    /** Fin du téléchargement (réussi si apk != null). */
    private void finishWith(File apk, String error) {
        active = false;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(true);
        Listener l = listener;
        if (apk != null) {
            if (l != null) l.onDone(apk); else notifyDone(apk);
        } else if (error != null) {
            if (l != null) l.onFail(error); else if (!cancelled) notifyFail(error);
        }
        stopSelf();
    }

    /* ---------- notifications ---------- */
    private void makeChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH_PROGRESS, "Téléchargements en cours", NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel(CH_DONE, "Téléchargements terminés", NotificationManager.IMPORTANCE_HIGH));
    }

    private Notification progressNotification(String title, String text, int per, boolean indeterminate) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pOpen = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent cancel = new Intent(this, DownloadService.class).setAction(ACTION_CANCEL);
        PendingIntent pCancel = PendingIntent.getService(this, 1, cancel, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_PROGRESS)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(pOpen)
                .addAction(0, "Annuler", pCancel)
                .setProgress(1000, Math.max(per, 0), indeterminate || per < 0);
        return b.build();
    }

    private void notifyDone(File apk) {
        Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(EXTRA_INSTALL, apk.getAbsolutePath());
        PendingIntent p = PendingIntent.getActivity(this, 2, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new NotificationCompat.Builder(this, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Téléchargement terminé")
                .setContentText("Touchez pour installer " + apk.getName())
                .setContentIntent(p)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(ID_DONE, n);
    }

    private void notifyFail(String msg) {
        Notification n = new NotificationCompat.Builder(this, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Téléchargement interrompu")
                .setContentText(msg)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(ID_DONE, n);
    }

    /* ---------- utilitaires ---------- */
    private static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte x : md.digest()) sb.append(String.format(Locale.ROOT, "%02x", x));
        return sb.toString();
    }

    static String mb(long n) { return String.format(Locale.FRANCE, "%.1f Mo", n / 1048576.0); }
}
