package app.beestore;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

/**
 * Publicités AdMob de Bee Store :
 *  - une bannière sous l'écran d'accueil (affichée ou cachée par le site avec BeeNative.banner) ;
 *  - une vidéo récompensée avant un téléchargement (BeeNative.rewardedReady / showRewarded).
 * Les identifiants viennent de res/values/strings.xml (pubs de test de Google tant qu'ils ne sont pas remplacés).
 */
final class Ads {

    interface Result { void on(String status); } // "rewarded", "closed" ou "error"

    private final Activity act;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final FrameLayout holder;
    private AdView banner;
    private volatile RewardedAd rewarded;
    private volatile boolean loading, ready;
    private boolean bannerWanted;

    Ads(Activity act, FrameLayout holder) {
        this.act = act;
        this.holder = holder;
    }

    /** À appeler une fois, hors du fil principal : démarre le SDK puis charge les pubs. */
    void start() {
        MobileAds.initialize(act, status -> ui.post(() -> {
            ready = true;
            loadRewarded();
            if (banner != null) banner.loadAd(new AdRequest.Builder().build());
        }));
    }

    /* ---------- bannière ---------- */
    void showBanner(boolean show) {
        bannerWanted = show;
        if (show && banner == null) {
            banner = new AdView(act);
            banner.setAdSize(AdSize.BANNER);
            banner.setAdUnitId(act.getString(R.string.admob_banner_id));
            holder.addView(banner, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
            if (ready) banner.loadAd(new AdRequest.Builder().build());
        }
        holder.setVisibility(show && banner != null ? View.VISIBLE : View.GONE);
        if (banner != null) { if (show) banner.resume(); else banner.pause(); }
    }

    void pause() { if (banner != null) banner.pause(); }
    void resume() { if (banner != null && bannerWanted) banner.resume(); }
    void destroy() { if (banner != null) { banner.destroy(); banner = null; } }

    /* ---------- vidéo récompensée ---------- */
    /** Vrai si une vidéo est prête ; sinon on en recharge une pour la prochaine fois. */
    boolean rewardedReady() {
        if (rewarded == null) ui.post(this::loadRewarded);
        return rewarded != null;
    }

    private void loadRewarded() {
        if (!ready || loading || rewarded != null) return;
        loading = true;
        RewardedAd.load(act, act.getString(R.string.admob_rewarded_id), new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(RewardedAd ad) { rewarded = ad; loading = false; }
            @Override public void onAdFailedToLoad(LoadAdError e) { rewarded = null; loading = false; }
        });
    }

    void showRewarded(final Result done) {
        final RewardedAd ad = rewarded;
        if (ad == null) { done.on("error"); return; }
        rewarded = null;
        final boolean[] earned = { false };
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override public void onAdDismissedFullScreenContent() {
                done.on(earned[0] ? "rewarded" : "closed");
                loadRewarded();
            }
            @Override public void onAdFailedToShowFullScreenContent(AdError e) {
                done.on("error");
                loadRewarded();
            }
        });
        ad.show(act, item -> earned[0] = true);
    }
}
